﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Permutari_BackTracing_recursiv
{
    internal class Program
    {
        private static int n;
        private static int[] x;
        static void Main(string[] args)
        {
            Console.Write("n =");
            n = int.Parse(Console.ReadLine());
            x = new int[n]; // Vectorul soluție (indexat de la 0 la n-1)
            Permutari(0); // Începem de la prima poziție (index 0)
        }

        private static void Permutari(int k)
        {
            // Parcurgem toate valorile posibile pentru poziția curentă 'k'
            for (int val = 1; val <= n; val++)
            {
                x[k] = val; // Punem valoarea în vectorul soluție

                if (IsValid(k)) // Dacă alegerea este validă parțial
                {
                    if (IsSolution(k))
                    {
                        PrintSolution(); // Am completat o soluție validă
                    }
                    else
                    {
                        Permutari(k + 1); // Trecem la pasul următor
                    }
                }
            }
        }

        private static bool IsValid(int k)
        {
            for (int i = 0; i < k; i++)
            {
                // Exemplu pentru permutări: toate elementele trebuie să fie distincte
                if (x[i] == x[k])
                {
                    return false;
                }
            }
            return true;
        }
        
        private static bool IsSolution(int k) // Verifică dacă am ajuns la ultimul element al soluției
        {
            return k == n - 1;
        }
        
        private static void PrintSolution() // Afișează elementele soluției găsite
        {
            Console.WriteLine(string.Join(" ", x));
        }
    }
}