﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Permutari_BackTracking_iterativ
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("n=");
            int n = int.Parse(Console.ReadLine());
            int[] x = new int[n]; // Vectorul soluție

            // Inițializăm vectorul cu o valoare inferioară primei opțiuni posibile
            for (int i = 0; i < n; i++) x[i] = 0;

            int k = 0; // Pornim de la prima poziție (index 0)

            while (k >= 0) // Cât timp mai avem poziții în stivă
            {
                x[k]++; // Trecem la următoarea valoare posibilă pentru poziția curentă

                // Căutăm o valoare validă în intervalul permis [1, n]
                while (x[k] <= n && !IsValid(x, k))
                {
                    x[k]++;
                }

                if (x[k] <= n) // Am găsit o valoare validă pentru poziția 'k'
                {
                    if (k == n - 1) // Este soluție completă?
                    {
                        PrintSolution(x);
                    }
                    else // Nu este completă, avansăm în stivă
                    {
                        k++;
                        x[k] = 0; // Resetăm poziția următoare pentru a reîncepe testarea de la 1
                    }
                }
                else // Am epuizat valorile pentru poziția 'k', facem pasul înapoi (backtrack)
                {
                    k--;
                }
            }
        }

        private static bool IsValid(int[] x, int k)
        {
            for (int i = 0; i < k; i++)
            {
                if (x[i] == x[k])
                {
                    return false;
                }
            }
            return true;
        }

        private static void PrintSolution(int[] x)
        {
            Console.WriteLine(string.Join(" ", x));
        }
    }
}