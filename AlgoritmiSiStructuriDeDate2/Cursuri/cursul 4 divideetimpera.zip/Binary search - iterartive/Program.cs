﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Binary_search___iterartive
{
    internal class Program
    {

        public static int BinarySearch(int[] arr, int target)
        {
            int left = 0;
            int right = arr.Length - 1;

            while (left <= right)
            {
                // asa previn depasirea limitei maxime pt int
                int mid = left + (right - left) / 2;

                if (arr[mid] == target) return mid;

                if (arr[mid] < target)
                    left = mid + 1; // cautam in dreapta
                else
                    right = mid - 1; // cautam in stanga
            }

            return -1; // Not found
        }
        static void Main(string[] args)
        {
            int[] numbers = new int[20];
            int target = 70;
            for (int i = 0; i < numbers.Length; i++)
            {
                numbers[i] = (i+1)*10;
            }
            var returnvalue = BinarySearch(numbers, target);
            if ( returnvalue == -1)
            {
                Console.WriteLine("Not found!!!");
            }
            else
            {
                Console.WriteLine("{0} found at position {1}",target, returnvalue);
            }
        }
    }
}