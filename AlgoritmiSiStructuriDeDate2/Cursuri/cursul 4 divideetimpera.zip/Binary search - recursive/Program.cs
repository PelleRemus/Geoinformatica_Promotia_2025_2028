﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Binary_search___recursive
{
    internal class Program
    {
        public static int BinarySearchRecursive(int[] v, int target, int left, int right)
        {
            if (left > right)
            {
                return -1;
            }

            int mid = left + (right - left) / 2;  // evit depasirea de valoare maxima pt int

            if (v[mid] == target)
            {
                return mid;
            }

            if (target < v[mid])
            {
                return BinarySearchRecursive(v, target, left, mid - 1);
            }
            else
            {
                return BinarySearchRecursive(v, target, mid + 1, right);
            }
        }
        static void Main(string[] args)
        {
            int[] numbers = new int[20];
            int target = 100;
            for (int i = 0; i < numbers.Length; i++)
            {
                numbers[i] = (i + 1) * 10;
            }
            var returnvalue = BinarySearchRecursive(numbers, target ,0 ,numbers.Length-1);
            if (returnvalue == -1)
            {
                Console.WriteLine("Not found!!!");
            }
            else
            {
                Console.WriteLine("{0} found at position {1}", target, returnvalue);
            }
        }
    }
}