﻿using System;
using System.Numerics; // adaugati si la referinte System.Numerics
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Karatsuba_Multiply
{
    internal class Program
    {
            // Threshold where schoolbook multiplication becomes faster than recursion
            private const int KaraCutoff = 10;

            public static BigInteger Multiply(BigInteger x, BigInteger y)
            {
                // Base case: Use standard multiplication for small numbers
                int n = Math.Max(x.ToString().Length, y.ToString().Length);
                if (n <= KaraCutoff)
                    return x * y;

                // Determine the split point
                int m = (n + 1) / 2;
                BigInteger powerOf10 = BigInteger.Pow(10, m);

                // Split the numbers into high (a, c) and low (b, d) parts
                BigInteger a = x / powerOf10;
                BigInteger b = x % powerOf10;
                BigInteger c = y / powerOf10;
                BigInteger d = y % powerOf10;

                // Recursive steps
                BigInteger ac = Multiply(a, c);
                BigInteger bd = Multiply(b, d);
                BigInteger abcd = Multiply(a + b, c + d);

                // Combine the results: ac * 10^(2m) + (abcd - ac - bd) * 10^m + bd
                return (ac * BigInteger.Pow(10, 2 * m)) +
                       ((abcd - ac - bd) * powerOf10) +
                       bd;
            }

        static void Main(string[] args)
        {
            BigInteger num1 = BigInteger.Parse("123456789012345678901234567890");
            BigInteger num2 = BigInteger.Parse("98765432109876543210");

            Console.WriteLine($"Result: {Multiply(num1, num2)}");
        }
    }
}
