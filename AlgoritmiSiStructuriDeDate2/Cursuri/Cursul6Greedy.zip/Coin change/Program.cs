﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Coin_change
{
    internal class Program
    {
        public static List<int> GetCoinsGreedy(int[] coins, int amount)
        {
            List<int> selectedCoins = new List<int>();

            foreach (int coin in coins)
            {
                // Ia din cea mai mare moneda maximul de monede posibil
                while (amount >= coin)
                {
                    amount -= coin;
                    selectedCoins.Add(coin);
                }
            }
            // daca nu am ajuns cu suma restului la zero nu avem solutie cu greedy
            return amount == 0 ? selectedCoins : null;
        }
        static void Main(string[] args)
        {
            // Definim valorile monedelor
            int[] coins = { 1, 5, 10, 25 }; 
            // definim restul
            int targetAmount = 63;

            // Se sorteaza daca e cazul in ordine descrescatoare a valorii pentu alegerea greedy
            Array.Sort(coins);
            Array.Reverse(coins);

            Console.WriteLine($"Target: {targetAmount}");
            Console.WriteLine("Monede folosite:");

            List<int> result = GetCoinsGreedy(coins, targetAmount);

            // Afisez rezultatul
            if (result == null)
                Console.WriteLine("Cu monedele date nu sunt posibile solutii");
            else
                Console.WriteLine(string.Join(", ", result) +
                                  $"\nTotal monede: {result.Count}");

        }
    }
}