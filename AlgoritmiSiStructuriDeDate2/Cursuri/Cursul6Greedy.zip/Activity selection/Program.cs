﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Activity_selection
{
    public class Activity
    {
        public string Name { get; set; }
        public int Start { get; set; }
        public int Finish { get; set; }

        public void Show()
        {
            Console.WriteLine($"{this.Name} (Start: {this.Start}, Finish: {this.Finish})");
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            // definim o lista de activitati
            List<Activity> activities = new List<Activity>
            {
                new Activity { Name = "A1", Start = 1, Finish = 2 },
                new Activity { Name = "A2", Start = 3, Finish = 4 },
                new Activity { Name = "A3", Start = 0, Finish = 6 },
                new Activity { Name = "A4", Start = 5, Finish = 7 },
                new Activity { Name = "A5", Start = 8, Finish = 9 },
                new Activity { Name = "A6", Start = 5, Finish = 9 }
             };

            //  Sortam activitatile dupa timpul de terminare (Greedy Choice)
            var sortedActivities = activities.OrderBy(a => a.Finish).ToList();

            List<Activity> selectedActivities = new List<Activity>();

            // tot timpul prima activitate e selectata automat

            if (sortedActivities.Count > 0)
            {
                Activity lastSelected = sortedActivities[0];
                selectedActivities.Add(lastSelected);

                // parcurgem restul activitatilor
                for (int i = 1; i < sortedActivities.Count; i++)
                {
                    // Daca aceasta activitate incepe dupa sau chiar cand se termina ultima activitate terminata
                    // se va adauga la lista de activitati selectate
                    if (sortedActivities[i].Start >= lastSelected.Finish)
                    {
                        selectedActivities.Add(sortedActivities[i]);
                        lastSelected = sortedActivities[i];
                    }
                }
            }

            // Afisarea rezultatului
            Console.WriteLine("Activitati selectate:");
            foreach (var act in selectedActivities)
            {
                act.Show();
            }
        }
    }
}
