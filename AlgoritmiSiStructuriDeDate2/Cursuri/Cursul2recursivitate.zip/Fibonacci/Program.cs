﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fibonacci
{
    internal class Program
    {
        static int Fibonacci(int n)
        {
            // Cazurile de bază: F(0) = 0, F(1) = 1
            if (n == 0 || n == 1)
                return n;

            // Apelul recursiv: F(n) = F(n-1) + F(n-2)
            return Fibonacci(n - 1) + Fibonacci(n - 2);
        }

        static void Main(string[] args)
        {
            Console.Write("Introdu numărul de termeni: n=");
            int n = int.Parse(Console.ReadLine());

            Console.WriteLine($"Primii {n} termeni sunt:");
            for (int i = 0; i <= n; i++)
            {
                Console.Write(Fibonacci(i) + " ");
            }
        }
    }
}
