﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ogliditul_nr
{
    internal class Program
    {
        static int k = 0;
        static void Oglinditul_nr(int n)
        {
            if (n > 0)
            {
                Console.Write(n % 10);
                Oglinditul_nr(n / 10);
            }
        }

        static int Oglinditul_nr_v2(int n, int rev=0)
        {
            if (n == 0) 
                return rev;
            else 
                return Oglinditul_nr_v2(n / 10, rev*10 + n%10);
        }

        static void Main(string[] args)
        {
            int n;
            Console.Write("n=");
            n=int.Parse(Console.ReadLine());
            Console.WriteLine(Oglinditul_nr_v2(n));
        }
    }
}
