﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Palindrom
{
    internal class Program
    {
        static bool EstePalindrom(string text)
        {
            // Caz de bază: un cuvânt cu 0 sau 1 caractere este mereu palindrom
            if (text.Length <= 1)
                return true;
            // Verificăm dacă prima și ultima literă sunt egale (ignorând majusculele)
            if (char.ToLower(text[0]) != char.ToLower(text[text.Length - 1]))
                return false;
            // Apel recursiv: verificăm substring-ul fără prima și ultima literă
            return EstePalindrom(text.Substring(1, text.Length - 2));
        }
        static void Main(string[] args)
        {
            Console.Write("Introdu cuvântul: ");
            string cuvant = Console.ReadLine();

            if (EstePalindrom(cuvant))
                Console.WriteLine($"'{cuvant}' este palindrom.");
            else
                Console.WriteLine($"'{cuvant}' nu este palindrom.");
        }
    }
}
