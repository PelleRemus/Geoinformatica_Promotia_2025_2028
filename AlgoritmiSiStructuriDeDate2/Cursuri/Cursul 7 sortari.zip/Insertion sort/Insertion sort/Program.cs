﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Insertion_sort
{
    internal class Program
    {
        public static void InsertionSort(int[] array)
        {
            for (int i = 1; i < array.Length; ++i)
            {
                int key = array[i];
                int j = i - 1;

                // Move elements of array[0..i-1] that are greater than key
                // to one position ahead of their current position
                while (j >= 0 && array[j] > key)
                {
                    array[j + 1] = array[j];
                    j = j - 1;
                }
                array[j + 1] = key;
            }
        }
        static void Main(string[] args)
        {
            int[] inputarray = { 30, 20, 10, 70, 50, 60, 90, 80, 40, 0, 100, 150, 130, 120, 110 };
            InsertionSort(inputarray);
            Console.WriteLine("Sorted array: " + string.Join(", ", inputarray));
        }
    }
}