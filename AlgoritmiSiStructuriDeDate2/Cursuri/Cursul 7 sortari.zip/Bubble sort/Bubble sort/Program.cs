﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bubble_sort
{
    internal class Program
    {
        static void OptimizedBubbleSort(int[] array)
        {
            bool swapped;
            for (int i = 0; i < array.Length - 1; i++)
            {
                swapped = false;
                for (int j = 0; j < array.Length - i - 1; j++)
                {
                    if (array[j] > array[j + 1])
                    {
                        (array[j], array[j + 1]) = (array[j + 1], array[j]); // C# Tuple Swap
                        swapped = true;
                    }
                }
                // If no two elements were swapped by inner loop, then break
                if (!swapped)
                    break;
            }
        }
        static void Main(string[] args)
        {
            int[] inputarray= { 30, 20, 10, 70, 50, 60, 90, 80, 40, 0, 100, 150, 130, 120, 110 };
            OptimizedBubbleSort (inputarray);
            Console.WriteLine("Sorted array: " + string.Join(", ", inputarray));
        }
    }
}