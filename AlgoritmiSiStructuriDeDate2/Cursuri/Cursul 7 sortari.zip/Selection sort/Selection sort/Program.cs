﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Selection_sort
{
    internal class Program
    {
        public static void SelectionSort(int[] arr)
        {
            int n = arr.Length;

            // One by one move the boundary of the unsorted subarray
            for (int i = 0; i < n - 1; i++)
            {
                // Find the minimum element in unsorted array
                int minIndex = i;
                for (int j = i + 1; j < n; j++)
                {
                    if (arr[j] < arr[minIndex])
                    {
                        minIndex = j;
                    }
                }

                // Swap the found minimum element with the first element
                if (minIndex != i)
                {
                    (arr[i], arr[minIndex]) = (arr[minIndex], arr[i]);
                }
            }
        }
        static void Main(string[] args)
        {
            int[] inputarray = { 30, 20, 10, 70, 50, 60, 90, 80, 40, 0, 100, 150, 130, 120, 110 };
            SelectionSort(inputarray);
            Console.WriteLine("Sorted array: " + string.Join(", ", inputarray));
        }
    }
}