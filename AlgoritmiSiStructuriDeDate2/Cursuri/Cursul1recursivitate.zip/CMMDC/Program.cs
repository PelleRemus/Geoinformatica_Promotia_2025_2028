﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMMDC
{
    internal class Program
    {
        static int CMMDC(int a,int b){ 
            if(a==0 || b==0) return 0;
            if (a == b) return a;
            if (a > b) return CMMDC(a - b, b);
            else return CMMDC(a, b - a);
        }
        static int CMMDC_Euclid(int a,int b)
        {
            if (b == 0) return a;
            else return CMMDC_Euclid(b, a % b);
        }
        static void Main(string[] args)
        {
            int a, b;
            Console.Write("introduceti un nr natural a=");
            a=int.Parse(Console.ReadLine());
            Console.Write("introduceti un nr natural b=");
            b=int.Parse(Console.ReadLine());
            Console.WriteLine("CMMDC({0},{1})={2}",a,b,CMMDC(a,b));
            Console.WriteLine("CMMDC_E({0},{1})={2}", a, b, CMMDC_Euclid(a, b));
        }
    }
}
