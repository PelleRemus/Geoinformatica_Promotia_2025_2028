﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace powerxy
{
    internal class Program
    {
        static int power_xy(int x,int y)
        {
            if (y == 0) return 1;
            else return x * power_xy(x, y - 1);          //x la puterea y este x*x la puatrea (y-1)
        }
        static void Main(string[] args)
        {
            // x la puterea y implementata recursiv;
            int x, y,pow_xy=1;
            Console.Write("introduceti o valoare pentru x=");
            x=int.Parse(Console.ReadLine());
            Console.Write("introduceti o valaore pentru y=");
            y=int.Parse(Console.ReadLine());
            /*if (y == 0)
                Console.WriteLine("{0} la puterea {1} este = {2}", x, y, pow_xy);
            else {
                for (int i = 1; i <= y; i++)
                    pow_xy = pow_xy * x; //pow_xy *= x;
                Console.WriteLine("{0} la puterea {1} este = {2}", x, y, pow_xy);
            }
            */
            Console.WriteLine("{0} la puterea {1} este = {2}", x, y, power_xy(x,y));
        }
    }
}
