﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Combinari_nk
{
    internal class Program
    {
        static int combinari_nk(int n,int k)
        {
            //C(n,k) = C(n-1,k-1)+C(n-1,k)
            if (k == 0 || k == n) return 1;
            else return combinari_nk(n - 1, k - 1) + combinari_nk(n - 1, k);
        }
        static void Main(string[] args)
        {
            int n,k;
            Console.Write("Introduceti o valoare intreaga pozitiva: n=");
            n=int.Parse(Console.ReadLine());
            Console.Write("Introduceti o valoare intreaga pozitiva: k=");
            k=int.Parse(Console.ReadLine());
            Console.WriteLine("Combinari de {0} luate cate {1} = {2}",n,k,combinari_nk(n,k));
        }
    }
}
