﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace factorial
{
    internal class Program
    {
        static int factorial(int x)  //tipul de return poate fi marit pentru a stoca numere cat mai mari
        {
            if (x == 0 || x == 1)
                return 1;
            else return x * factorial(x - 1);
        }
        static void Main(string[] args)
        {
            int n;
            Console.Write("Introduceti o valoare intreaga poziitva n=");
            n= int.Parse(Console.ReadLine());
            Console.WriteLine("Factorialul lui n este n! = {0}",factorial(Math.Abs(n)));
        }
    }
}