﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuickSort
{
    internal class Program
    {
        public static void QuickSort(int[] array, int left, int right)
        {
            if (left < right)
            {
                // 1. Partition the array and get the pivot index
                int pivotIndex = Partition(array, left, right);

                // 2. Recursively sort the elements before and after the pivot
                QuickSort(array, left, pivotIndex - 1);
                QuickSort(array, pivotIndex + 1, right);
            }
        }

        private static int Partition(int[] array, int left, int right)
        {
            int pivot = array[right]; // Choosing the last element as pivot
            int i = left - 1;         // Index of the smaller element

            for (int j = left; j < right; j++)
            {
                if (array[j] <= pivot)
                {
                    i++;
                    // Swap elements at i and j
                    (array[i], array[j]) = (array[j], array[i]);
                }
            }

            // Place the pivot in its final sorted position
            (array[i + 1], array[right]) = (array[right], array[i + 1]);
            return i + 1;
        }

        static void Main(string[] args)
        {
            int[] myarray = new int[10] { 5, 6, 7, 1, 4, 9, 8, 10, 2, 3 };  
            QuickSort(myarray,0, myarray.Length - 1);
            for (int i = 0; i < myarray.Length; i++)
            {
                Console.Write("{0} ",myarray[i]);
            }
        }
    }
}
