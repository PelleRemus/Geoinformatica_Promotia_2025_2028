﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Closest_pair_of_points
{
    public struct Point
    {
        public double X, Y;
        public Point(double x, double y) { X = x; Y = y; }
    }

    public class ClosestPairSolver
    {
        public static double GetDistance(Point p1, Point p2)
        {
            return Math.Sqrt(Math.Pow(p1.X - p2.X, 2) + Math.Pow(p1.Y - p2.Y, 2));
        }

        public static double FindMinimumDistance(List<Point> points)
        {
            // Sort points initially by X-coordinate
            var sortedX = points.OrderBy(p => p.X).ToList();
            return SolveRecursive(sortedX);
        }

        private static double SolveRecursive(List<Point> pointsByX)
        {
            int n = pointsByX.Count;

            // Base case: Use brute force for small subsets (3 points or fewer)
            if (n <= 3) return BruteForce(pointsByX);

            // Divide: Split the points into two halves
            int mid = n / 2;
            var leftHalf = pointsByX.Take(mid).ToList();
            var rightHalf = pointsByX.Skip(mid).ToList();

            // Conquer: Find the minimum distance in each half
            double d = Math.Min(SolveRecursive(leftHalf), SolveRecursive(rightHalf));

            // Combine: Check for points that cross the dividing line
            var strip = pointsByX.Where(p => Math.Abs(p.X - pointsByX[mid].X) < d)
                                 .OrderBy(p => p.Y).ToList();

            // Check the strip (inner loop runs at most 7-8 times per point)
            for (int i = 0; i < strip.Count; i++)
            {
                for (int j = i + 1; j < strip.Count && (strip[j].Y - strip[i].Y) < d; j++)
                {
                    d = Math.Min(d, GetDistance(strip[i], strip[j]));
                }
            }
            return d;
        }
        
        private static double BruteForce(List<Point> points)
        {
            double min = double.MaxValue;
            for (int i = 0; i < points.Count; i++)
                for (int j = i + 1; j < points.Count; j++)
                    min = Math.Min(min, GetDistance(points[i], points[j]));
            return min;
        }
    }


    internal class Program
    {
        static void Main(string[] args)
        {
            Random rng = new Random();
            List<Point> points = new List<Point>();

            for (int i = 0; i < 32; i++)
            {
                points.Add(new Point(rng.NextDouble() * 200, rng.NextDouble() * 200));
            }
            double result = ClosestPairSolver.FindMinimumDistance(points);
            Console.WriteLine("Minimum Distance: {0:F4}",result);
        }
    }
}
