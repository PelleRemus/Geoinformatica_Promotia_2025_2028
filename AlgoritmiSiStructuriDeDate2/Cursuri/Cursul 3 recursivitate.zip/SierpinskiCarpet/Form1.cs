﻿namespace SierpinskiCarpet
{
    public partial class SierpinskiCarpet : Form
    {

        private readonly int nivelAdancime = 5;
        public SierpinskiCarpet()
        {
            this.Text = "Covorul lui Sierpinski";
            this.Size = new Size(600, 600);
            this.Paint += new PaintEventHandler(DesenareCovor);
            InitializeComponent();
        }

        private void SierpinskiCarpet_Load(object sender, EventArgs e)
        {
            //ceva
        }

        private void DesenareCovor(object? sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Color.White);

            // Coordonate inițiale (x, y, dimensiune, nivel)
            DeseneazaRecursiv(g, 1, 1, this.ClientSize.Height -2, nivelAdancime);
        }

        private void DeseneazaRecursiv(Graphics g, float x, float y, float size, int level)
        {
            if (level == 0)
            {
                // Desenează pătratul plin la ultimul nivel de recursivitate
                g.FillRectangle(Brushes.Black, x, y, size, size);
                return;
            }

            // Împarte latura la 3 pentru noile sub-pătrate
            float newSize = size / 3;

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    // Sari peste pătratul central (i=1, j=1)
                    if (i == 1 && j == 1) continue;

                    // Apelează recursiv pentru cele 8 pătrate exterioare
                    DeseneazaRecursiv(g, x + i * newSize, y + j * newSize, newSize, level - 1);
                }
            }
        }
    }
}