﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TurnurileHanoi
{
    internal class Program
    {
        static void Hanoi(int n, char sursa, char destinatie, char auxiliar)
        {
            // Cazul de bază: dacă nu mai sunt discuri de mutat, ieșim din recursivitate
            if (n == 0) return;

            // Pasul 1: Mută n-1 discuri de la Sursă la Auxiliară
            Hanoi(n - 1, sursa, auxiliar, destinatie);

            // Pasul 2: Mută discul curent la Destinație
            Console.WriteLine($"Mută discul {n} de la {sursa} la {destinatie}");

            // Pasul 3: Mută cele n-1 discuri de la Auxiliară la Destinație
            Hanoi(n - 1, auxiliar, destinatie, sursa);
        }

        static void Main(string[] args)
        {
            Console.Write("Introdu numărul de discuri: ");
            int n = int.Parse(Console.ReadLine());

            // Apelăm funcția: n discuri, de la tija A la tija C, folosind B ca ajutor
            Hanoi(n, 'A', 'C', 'B');

            // (2 ^ n) -1 mutari
        }
    }
}
