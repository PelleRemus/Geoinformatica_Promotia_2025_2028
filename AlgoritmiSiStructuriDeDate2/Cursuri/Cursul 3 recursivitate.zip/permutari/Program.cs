﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace permutari
{
    internal class Program
    {
        static void Schimba(int[] v, int i, int j)
        {
            int temp = v[i];
            v[i] = v[j];
            v[j] = temp;
        }

        static void Afisare(int[] v)
        {
            Console.WriteLine(string.Join(" ", v));
        }

        static void GenerarePermutari(int[] v, int n)
        {
            // Cazul de bază: am redus problema la un singur element
            if (n == 1)
            {
                Afisare(v);
                return;
            }

            for (int i = 0; i < n; i++)
            {
                // Mutăm elementul de la indexul i pe ultima poziție disponibilă (n-1)
                Schimba(v, i, n - 1);

                // Generăm permutările pentru restul de n-1 elemente
                GenerarePermutari(v, n - 1);

                // Revenim la starea inițială (Backtracking)
                Schimba(v, i, n - 1);
            }
        }

        static void Main(string[] args)
        {
            Console.Write("Introduceti n= ");
            if (int.TryParse(Console.ReadLine(), out int n))
            {
                int[] elemente = new int[n];
                for (int i = 0; i < n; i++) elemente[i] = i + 1;

                Console.WriteLine("Permutările sunt:");
                GenerarePermutari(elemente, n);
                // n! numarul permutarilor multimii nu n elemente
            }
        }
    }
}
