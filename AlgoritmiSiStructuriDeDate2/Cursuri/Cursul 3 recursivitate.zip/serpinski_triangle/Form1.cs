﻿namespace serpinski_triangle
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.Paint += new PaintEventHandler(DrawSierpinski);
        }

        private void DrawSierpinski(object? sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

            // Definim punctele triunghiului principal
            PointF p1 = new PointF(this.ClientSize.Width / 2, 2);
            PointF p2 = new PointF(2, this.ClientSize.Height - 2);
            PointF p3 = new PointF(this.ClientSize.Width - 2, this.ClientSize.Height - 2);

            // Nivelul de adâncime (de exemplu, 5 sau 6 pentru vizibilitate optimă)
            DeseneazaFractal(g, 10, p1, p2, p3);
        }

        private void DeseneazaFractal(Graphics g, int nivel, PointF p1, PointF p2, PointF p3)
        {
            if (nivel == 0)
            {
                // Cazul de bază: desenează triunghiul plin
                PointF[] puncte = { p1, p2, p3 };
                g.FillPolygon(Brushes.DarkBlue, puncte);
            }
            else
            {
                // Calculăm mijlocul laturilor
                PointF m1 = new PointF((p1.X + p2.X) / 2, (p1.Y + p2.Y) / 2);
                PointF m2 = new PointF((p2.X + p3.X) / 2, (p2.Y + p3.Y) / 2);
                PointF m3 = new PointF((p1.X + p3.X) / 2, (p1.Y + p3.Y) / 2);

                // Apeluri recursive pentru cele 3 triunghiuri mici din colțuri
                DeseneazaFractal(g, nivel - 1, p1, m1, m3);
                DeseneazaFractal(g, nivel - 1, m1, p2, m2);
                DeseneazaFractal(g, nivel - 1, m3, m2, p3);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
